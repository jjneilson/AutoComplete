/*
 * ACmain.cpp
 *
 *  Created on: Nov 16, 2021
 *      Author: jackneilson
 */

#include <iostream>
#include "AC.hpp"
//#include <conio>
//#include <windows>

int main(void) {
	AC("DrSeuss.txt");
	//AC wordset("DrSeuss.txt",true);
	//AC wordset("SmallSeuss.txt");
	//AC wordset("SmallSeuss.txt",true);
	return 0;
}

